var indexSectionsWithContent =
{
  0: "chimotv",
  1: "tv",
  2: "v",
  3: "cm",
  4: "himo"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

