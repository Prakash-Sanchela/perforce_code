var searchData=
[
  ['hour_0',['hour',['../struct_time.html#a15df9ba285cfd842f284025f904edc9c',1,'Time']]]
];
