var searchData=
[
  ['minute_0',['minute',['../struct_time.html#a5edffad982a0566ad01d95005474eae3',1,'Time']]]
];
